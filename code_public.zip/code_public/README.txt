MATLAB code to reproduce experiments described in
Optimal kernel choice for large-scale two-sample tests.
Advances in Neural Information Processing Systems 2012.
Gretton, A., Sriperumbudur, B., Sejdinovic, D., Strathmann, H.,
Balakrishnan, S., Pontil, M., & Fukumizu, K.

Start script is standalone.m, see file for instructions.

Written by Heiko Strathmann under GPLv3, see License.txt for a copy.
